import sys
import time
import pprint
import networkx as nx
import numpy as np
# import matplotlib.pyplot as plt
import random

from web3 import *
from solc import compile_source
import os

n = 10
#Creating the Graph
network_graph = nx.Graph()
#adding the nodes to the Graph based on the argument of n provided by the user
for i in range(n):
    network_graph.add_node(i)


def compile_source_file(file_path):
   with open(file_path, 'r') as f:
      source = f.read()
   return compile_source(source)

#********************************************************************************************************************* 
def getContractInstance(address):
    contract_source_path = os.environ['HOME']+'/HW3/SmartContract.sol'
    compiled_sol = compile_source_file(contract_source_path)

    contract_id, contract_interface = compiled_sol.popitem()

    MyContract = w3.eth.contract(
    address=address,
    abi=contract_interface['abi'])

    return MyContract    
# *********************************************************************************************************************
def RegisterUser(MyContract):
    print("MyAccount",w3.eth.accounts[0])
    # Registering "n" users

    w3.miner.start(1)
    balance = w3.eth.getBalance(w3.eth.accounts[0])
    print("Initial balance of Account: ",w3.fromWei(balance,'ether'))

    print("Transaction Count ",w3.eth.getTransactionCount(w3.eth.accounts[0]))
    for i in range(n):
        tx_hash = MyContract.functions.registerUser(i,"user"+str(i)).transact({'txType':"0x3", 'from':w3.eth.accounts[0], 'gas':2409638})
        print("Registering User",i,"    TxnHash:",w3.toHex(tx_hash))

        
    receipt3 = w3.eth.getTransactionReceipt(tx_hash)

    while ((receipt3 is None)) : 
        time.sleep(0.1)

        receipt3 = w3.eth.getTransactionReceipt(tx_hash)
        # break


    receipt3 = w3.eth.getTransactionReceipt(tx_hash)

    if receipt3 is not None:
        balance = w3.eth.getBalance(w3.eth.accounts[0])
        print("balance of Account After All User Registered : ",w3.fromWei(balance,'ether'))
        print("Transaction Count after last User registered")
        print("Transaction Count ",w3.eth.getTransactionCount(w3.eth.accounts[0]))
        print("Gas Fee and Block Number of Transaction of last registered user")
        print("gasUsed:{0}".format(receipt3['gasUsed']),"blockNumber:{0}".format(receipt3['blockNumber']))

    w3.miner.stop()

# *********************************************************************************************************************
def CreateAccount(MyContract):
 #Creating Accounts between nodes i.e. adding edges between them 
#Randomly connecting the graph by adding edges between randomly selected nodes.
    w3.miner.start(1)
    balance = w3.eth.getBalance(w3.eth.accounts[0])
    print("balance of Account before Adding edges: ",w3.fromWei(balance,'ether'))
    print("Transaction Count before Adding edges")
    print("Transaction Count ",w3.eth.getTransactionCount(w3.eth.accounts[0]))
    while nx.is_connected(network_graph) == False:
        c1 = random.choice(list(network_graph.nodes()))
        c2 = random.choice(list(network_graph.nodes()))

        amount = np.random.exponential(scale=10)
        amount =amount/2

        if c1 != c2 and network_graph.has_edge(c1, c2) == 0: #Ensuring edge already doesn't exist between the selected nodes.
            network_graph.add_edge(c1, c2)
            tx_hash = MyContract.functions.createAcc(c1,c2,int(amount),int(amount)).transact({'txType':"0x3", 'from':w3.eth.accounts[0], 'gas':2409638})
            print("Adding Edge between ",c1," and ",c2,"    TxnHash: ",w3.toHex(tx_hash))
            
    receipt3 = w3.eth.getTransactionReceipt(tx_hash)

    while ((receipt3 is None)) : 
        time.sleep(0.1)
        receipt3 = w3.eth.getTransactionReceipt(tx_hash)
        # break


    receipt3 = w3.eth.getTransactionReceipt(tx_hash)

    if receipt3 is not None:
        balance = w3.eth.getBalance(w3.eth.accounts[0])
        print("balance of Account After Adding all edges: ",w3.fromWei(balance,'ether'))
        print("Transaction Count after adding all the edges")
        print("Transaction Count ",w3.eth.getTransactionCount(w3.eth.accounts[0]))
        print("Gas Fee and Block Number of Transaction of last added edge")
        print("gasUsed:{0}".format(receipt3['gasUsed']),"blockNumber:{0}".format(receipt3['blockNumber']))

    w3.miner.stop()
# *********************************************************************************************************************            

def SendAmount(MyContract):
    sendTxnCount = 0
    w3.miner.start(1)
    while sendTxnCount < 100 :
        source = random.choice(list(network_graph.nodes()))
        dest = random.choice(list(network_graph.nodes()))

        if source != dest :
            sendTxnCount += 1

            tx_hash = MyContract.functions.sendAmount(source,dest).transact({'txType':"0x3", 'from':w3.eth.accounts[0], 'gas':2409638})
            sendTxnCount += 1
            print("Sending Amount from ",source," to ",dest)

            receipt3 = w3.eth.getTransactionReceipt(tx_hash)

            while ((receipt3 is None)) : 
                time.sleep(0.1)
                receipt3 = w3.eth.getTransactionReceipt(tx_hash)
                # break


            receipt3 = w3.eth.getTransactionReceipt(tx_hash)

            if receipt3 is not None:
                balance = w3.eth.getBalance(w3.eth.accounts[0])
                print("balance of Account Aftet performing SendAmount: ",w3.fromWei(balance,'ether'))
                print("Transaction Count ",w3.eth.getTransactionCount(w3.eth.accounts[0]))
                print("gasUsed:{0}".format(receipt3['gasUsed']),"blockNumber:{0}".format(receipt3['blockNumber']))

    
    w3.miner.stop()



       
    


w3 = Web3(IPCProvider(os.environ['HOME']+'/HW3/test-eth1/geth.ipc', timeout=100000))


i=0

while i < 1:
    with open(os.environ['HOME']+'/HW3/contractAddressList') as fp:
        for line in fp:
            #print(line)
            a,b = line.rstrip().split(':', 1)
            if a=="empty":  
                # tx_hash3 = sendEmptyLoopTransaction(b)
                MyContract = getContractInstance(b)
                 
            time.sleep(0.01)

    print("inside loop")

    i=i+1

print("*************************************STARTING REGISTER USER FUNCTION CALL*****************************************")
RegisterUser(MyContract)
print("*************************************START CREATE ACCOUNT FUNCTION CALL*****************************************")
CreateAccount(MyContract)
print("*************************************START SEND AMOUNT FUNCTION CALL*****************************************")
SendAmount(MyContract)

